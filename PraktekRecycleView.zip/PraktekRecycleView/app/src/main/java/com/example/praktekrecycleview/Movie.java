package com.example.praktekrecycleview;

public class Movie {
    private String Title;
    private String Year;

    public Movie(String title, String year) {
        Title = title;
        Year = year;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getYear() {
        return Year;
    }

    public void setYear(String year) {
        Year = year;
    }
}
